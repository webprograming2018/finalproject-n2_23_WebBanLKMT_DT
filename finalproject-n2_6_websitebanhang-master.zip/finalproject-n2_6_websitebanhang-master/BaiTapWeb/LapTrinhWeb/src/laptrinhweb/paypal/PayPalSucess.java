package laptrinhweb.paypal;

public class PayPalSucess {

}
