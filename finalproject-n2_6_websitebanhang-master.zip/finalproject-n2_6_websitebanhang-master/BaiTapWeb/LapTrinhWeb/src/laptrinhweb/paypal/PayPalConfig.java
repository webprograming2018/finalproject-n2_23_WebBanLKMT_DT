package laptrinhweb.paypal;

public class PayPalConfig {

}
