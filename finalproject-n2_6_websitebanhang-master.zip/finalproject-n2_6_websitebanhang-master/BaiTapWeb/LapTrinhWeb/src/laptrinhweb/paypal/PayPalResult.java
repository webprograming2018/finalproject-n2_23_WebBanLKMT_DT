package laptrinhweb.paypal;

public class PayPalResult {

}
