package laptrinhweb.service;

public interface PayPalService {

}
